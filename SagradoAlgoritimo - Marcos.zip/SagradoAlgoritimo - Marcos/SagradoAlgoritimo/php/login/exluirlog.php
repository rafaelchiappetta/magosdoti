<?php
require('conexao.php');


$idproduto = $_GET['idproduto'];
$sql = "delete from tblogin where idproduto='$idproduto'";
$qry = mysqli_query($con,$sql);

if($qry){
    HEADER('Location:listarlogin.php');
    
}else{
        echo "Não excluido";
    }





?>