<?php
require("conexao.php");

//se o conteudo da variavel "enviado" existir..
// so existe se o usuario clicar em cadastrar 
if(isset($_POST['enviado'])) {
    $nome  = $_POST['nome'];
    $email   = $_POST['email'];
    $telefone     = $_POST['telefone'];
    $senha = $_POST['senha'];
    // variavel com o comando de insert SQL
    $sql = "insert into tblogin (nome,email,telefone,senha)
    value ('$nome','$email','$telefone','$senha')";

    $qry = mysqli_query($con,$sql);
    if($qry) {
        echo "cadastro com com sucesso!!!";
    }else{
        echo"Não cadastrou";
    }
}
?>
<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Hello, world!</title>
    <style>
        *{
            margin: 0;
        }
        body{
            background-image: url(fundo2.2.jpg);
            background-repeat: no-repeat;
            background-size: cover;
        }
        .container{
            max-width: 1200px;
            height: 3200px;
            margin: 0px auto;
            background-color: #fff;
        }
        .carin{
            width: 30px;
            height: 30px;
        }
        .faixa{
            background-color: #00aa99;
        }
        .chamada{
            text-align: left;
        }
        .acc{
            width: 200px;
            height: 200px;  
        }
        .paralax{
            background-image: url(paralax.jpg);
            background-position: center top;
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            height: 400px;
        }
        .texto{
            padding-top: 100px;
        
        }
        .logo{
            height: 50px;
        }
        .ftprod{
            background-position: center top;
            width: 250px;
            height: 250px;
        }
        .corpoc{
            height: 150px;
        }
        .cad{

            padding: 20px
        }

 
    </style>
    
  </head>
  <body>
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top navbar-dark bg-dark" class="btn-info">
                <a class="navbar-brand" href="#">Sagrado algoritimo</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.html">home<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contato.html">contato<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="comochegar.html">Como chegar<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        produtos
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="games.html">games</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="pecas.html">peças</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="acessorios.html">Acessorios</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="vestuario.html">Vestuário</a>
                        </div>
                        <li class="nav-item">
                            <a class="nav-link" href="carinho.html"><img src="shopping-cart.png" class="carin"></a>
                        </li>
                    </li>
                    </ul>
                    <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Pesquisar" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
                    </form>
                </div>
            </nav>
            <section class="cad mt-4">
                <form method="POST">
                    <h1 class="text-center mt 4">Cadastro de usuários</h1>
                    <div class="form-group">
                        <label for="nome">Nome:</label>
                        <input type="text" name="nome" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="email">E-mail:</label>
                        <input type="email" name="email" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="tel">Telefone:</label>
                        <input type="tel" name="tel" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="nome">senha:</label>
                        <input type="password"  name="senha" class="form-control" />
                    </div>
                    <input type="hidden" name="enviado" value="ok">
                    <input type="submit" value="cadastar" class="btn btn-outline-success">
                </form>
            </section>    
        </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>