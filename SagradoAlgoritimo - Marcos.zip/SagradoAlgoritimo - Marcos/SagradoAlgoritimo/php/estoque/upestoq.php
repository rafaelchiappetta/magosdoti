<?php 
require('conexao.php'); //mesma função do include

if(isset($_POST['enviado'])){
	$idproduto	=$_POST['idproduto'];
	$produto	=$_POST['produto'];
	$estqatual	=$_POST['estqatual'];
    $estqmax		=$_POST['estqmax'];
    $estqmin		=$_POST['estqmin'];


	$sql="UPDATE tblestoque SET produto='$produto',estqatual='$estqatual',estqmax='$estqmax',estqmin='$estqmin' where idproduto='$idproduto'";
	$qry=mysqli_query($con,$sql);
		if($qry){
			header('Location:ltsestoque.php');
		}else{
			echo "Não atualizou";
		}
}else if(isset($_GET['idproduto'])){ //para exibir os dados no form
	$sql		="select * from tbestoque where idproduto=".$_GET['idproduto'];
	$qry		=mysqli_query($con,$sql); //executa o comando sql
	$linha		=mysqli_fetch_array($qry); //busca os dados em forma de array e armazena na variavel $linha

	$idproduto	=$linha['idproduto']; //pega o indice idpaciente e poe na variavel
	$produto	=$linha['produto'];
	$estqatual    =$linha['estqatual'];
    $estqmax		=$linha['estqmax'];
    $estqmin		=$linha['estqmin'];
}
?>
<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Hello, world!</title>
    <link rel="stylesheet" href="estilo/estiloo.css">
    
  </head>
  <body>
        <div class="container">
            <form method="POST">
                <section class="cad mt-4">
                    <h1 class="text-center">Edição de Estoque</h1>
                    <div class="form-group">
                        <label for="nome">idproduto:</label>
                        <input type="text" name="idproduto" class="form-control"  value="<?php echo $idproduto ?>" />
                    </div>
                    <div class="form-group">
                        <label for="nome">produto:</label>
                        <input type="text" name="produto" class="form-control" value="<?php echo $produto ?>" />
                    </div>
                    <div class="form-group">
                        <label for="nome">estoque atual:</label>
                        <input type="text" name="estqatual" class="form-control" value="<?php echo $estqatual ?>" />
                    </div>
                    <div class="form-group">
                        <label for="nome">estoque maximo:</label>
                        <input type="text" name="estqmax" class="form-control" value="<?php echo $estqmax ?>" />
                    </div>
                    <div class="form-group">
                        <label for="nome">estoque minimo:</label>
                        <input type="text" name="estqmin" class="form-control" value="<?php echo $estqmin ?>" />
                    </div>
                    
                    <input type="hidden" name="enviado" value="ok">
                    <input type="submit" value="cadastar" class="btn btn-outline-success">
                    <a href="listarestoque.php"  class="btn btn-outline-success" >Voltar</a>
                </section>  
            </form>  
        </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>