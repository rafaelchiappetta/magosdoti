<?php
require('conexao.php');


$idproduto = $_GET['idproduto'];
$sql = "delete from tbestoque where idproduto='$idproduto'";
$qry = mysqli_query($con,$sql);

if($qry){
    HEADER('Location:listarestoque.php');
    
}else{
        echo "Não excluido";
    }





?>