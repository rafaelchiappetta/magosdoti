<?php

require("conexao.php");

//se o conteudo da variavel "enviado" existir..
// so existe se o usuario clicar em cadastrar 
if(isset($_POST['enviado'])) {
    $codbarra = $_POST['codbarra'];
    $produto = $_POST['produto'];
    $preco = $_POST['preco'];
    $estqatual = $_POST['estqatual'];
    $estqmax = $_POST['estqmax'];
    $estqmin = $_POST['estqmin'];
    // variavel com o comando de insert SQL
    $sql = "insert into tbestoque (codbarra,produto,preco,estqatual,estqmax,estqmin)
    value ('$codbarra','$produto','$preco','$estqatual','$estqmax','$estqmin')";

    $qry = mysqli_query($con,$sql);
    if($qry) {
        echo "cadastro com com sucesso!!!";
    }else{
        echo"Não cadastrou";
    }
}
?>
<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Hello, world!</title>
    <link rel="stylesheet" href="estilo/estiloo.css">
    
  </head>
  <body>
        <div class="container">
            <form method="POST">
                <section class="cad mt-4">
                    <h1 class="text-center">Cadastro de usuários</h1>
                    <div class="form-group">
                        <label for="nome">codigo de barra:</label>
                        <input type="text" name="codbarra" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="nome">produto:</label>
                        <input type="text" name="produto" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="nome">preco:</label>
                        <input type="text" name="preco" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="nome">estoque atual:</label>
                        <input type="text" name="estqatual" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="nome">estoque maximo:</label>
                        <input type="text" name="estqmax" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="nome">estoque minimo:</label>
                        <input type="text" name="estqmin" class="form-control" />
                    </div>
                    
                    <input type="hidden" name="enviado" value="ok">
                    <input type="submit" value="cadastar" class="btn btn-outline-success">
                </section>  
            </form>  
        </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>