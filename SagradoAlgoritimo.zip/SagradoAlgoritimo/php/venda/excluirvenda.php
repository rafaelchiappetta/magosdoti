<?php
require('conexao.php');


$idvenda = $_GET['idvenda'];
$sql = "delete from tbvendas where idvenda='$idvenda'";
$qry = mysqli_query($con,$sql);

if($qry){
    HEADER('Location:listarvendas.php');
    
}else{
        echo "Não excluido";
    }





?>