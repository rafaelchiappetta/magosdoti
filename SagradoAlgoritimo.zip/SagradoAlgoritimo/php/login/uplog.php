<?php 
require('conexao.php'); //mesma função do include

if(isset($_POST['enviado'])){
	$idnome	=$_POST['idnome'];
	$nome	=$_POST['nome'];
	$email	=$_POST['email'];
    $telefone		=$_POST['telefone'];
    $senha		=$_POST['senha'];


	$sql="UPDATE tblestoque SET nome='$nome',email='$email',telefone='$telefone',senha='$senha' where idnome='$idnome'";
	$qry=mysqli_query($con,$sql);
		if($qry){
			header('Location:ltsestoque.php');
		}else{
			echo "Não atualizou";
		}
}else if(isset($_GET['idnome'])){ //para exibir os dados no form
	$sql		="select * from tbestoque where idnome=".$_GET['idnome'];
	$qry		=mysqli_query($con,$sql); //executa o comando sql
	$linha		=mysqli_fetch_array($qry); //busca os dados em forma de array e armazena na variavel $linha

	$idnome	=$linha['idnome']; //pega o indice idpaciente e poe na variavel
	$nome	=$linha['nome'];
	$email    =$linha['email'];
    $telefone		=$linha['telefone'];
    $senha		=$linha['senha'];
}
?>
<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Hello, world!</title>
    <link rel="stylesheet" href="estilo/estiloo.css">
    
  </head>
  <body>
        <div class="container">
            <form method="POST">
                <section class="cad mt-4">
                    <h1 class="text-center">Edição de Estoque</h1>
                    <div class="form-group">
                        <label for="nome">idnome:</label>
                        <input type="text" name="idnome" class="form-control"  value="<?php echo $idnome ?>" />
                    </div>
                    <div class="form-group">
                        <label for="nome">Nome:</label>
                        <input type="text" name="nome" class="form-control" value="<?php echo $nome ?>" />
                    </div>
                    <div class="form-group">
                        <label for="nome">E-mail:</label>
                        <input type="email" name="email" class="form-control" value="<?php echo $email ?>" />
                    </div>
                    <div class="form-group">
                        <label for="nome">telefone:</label>
                        <input type="tel" name="telefone" class="form-control" value="<?php echo $telefone ?>" />
                    </div>
                    <div class="form-group">
                        <label for="nome">senha:</label>
                        <input type="text" name="senha" class="form-control" value="<?php echo $senha ?>" />
                    </div>
                    
                    <input type="hidden" name="enviado" value="ok">
                    <input type="submit" value="cadastar" class="btn btn-outline-success">
                    <a href="listarlogin.php"  class="btn btn-outline-success" >Voltar</a>
                </section>  
            </form>  
        </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>