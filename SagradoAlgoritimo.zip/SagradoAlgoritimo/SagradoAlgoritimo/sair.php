<?php

session_start();
unset($_SESSION['idnome'], $_SESSION['nome'], $_SESSION['email']);

$_SESSION['msg'] = "Deslogado com sucesso";
header("Location: home.php");