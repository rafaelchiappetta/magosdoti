<?php

$sever = "127.0.0.1";
$user = "root";
$pass = "";
$bd = "bdpizza";

$con = mysqli_connect($sever,$user,$pass,$bd);
    if(!$con){
        echo "<h1>Não conectou ao BD</h1>";
        echo "foda se";
    }
